# CodeIgniter & Ajax
Simple Create, Update, Read, and Delete Data from MySQL Database using  CodeIgniter Framework and Ajax
