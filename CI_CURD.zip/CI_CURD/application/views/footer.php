<footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>Copyright &copy; G-Diary 2016</p>
                </div>
            </div>
        </div>
    </footer>
<!-- jQuery -->
    <script src="<?php echo base_url();?>assets/grocery_crud/themes/bootsrap/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/grocery_crud/themes/bootsrap/js/bootstrap.min.js"></script>

    <!-- Script to Activate the Carousel -->
    <script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>